=== Bitcoin faucet ===
Contributors: FaucetPay
Tags: btc, bitcoin, faucet, blockchain-wallet
Requires at least: 4.0.1
Tested up to: 4.9.4
Stable tag: 4.9.4
License: MIT

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/faucetpay_wordpress` directory, or install the plugin through the WordPress plugins screen directly
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the "Bitcoin Faucet" screen to configure the plugin

== Screenshots ==

1. Configuration page
2. Tooltips specification
3. Calculator in action










Modified Version from https://99bitcoins.com/