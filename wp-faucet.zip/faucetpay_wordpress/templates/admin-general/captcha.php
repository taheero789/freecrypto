<input type="hidden" name="config[captchas][]" value="">
<div id="general-captcha" class="the99tab" style="display: none">
    <?php include __DIR__ . '/captcha/empty.php' ?>
    <?php include __DIR__ . '/captcha/recaptcha.php' ?>
    <?php include __DIR__ . '/captcha/solvemedia.php' ?>
    <?php include __DIR__ . '/captcha/raincaptcha.php' ?>
</div>
