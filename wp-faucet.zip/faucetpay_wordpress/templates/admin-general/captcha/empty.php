<?php
/**
 * @var The99Bitcoins_BtcFaucet_Plugin $this
 * @var array $config
 * @var array $claim_rules
 * @var array $seniority_rules
 *
 * @var string $notice_message
 * @var string $notice_css_class
 */
?>
<h4>
    <input type="radio" name="config[captcha]" value="empty" id="config[captcha][empty]" style="position: relative; top: 2px"<?php if ($config['captcha'] == 'empty'): ?> checked="checked"<?php endif ?>> <label for="config[captcha][empty]"><?= esc_html__('No captcha', '99btc-bf') ?></label><br>
    <input type="checkbox" name="config[captchas][]" value="empty" id="config[captchas][empty]" style="position: relative; top: 2px"<?php if (!empty($config['captchas']) && in_array('empty', $config['captchas'])): ?> checked="checked"<?php endif ?>> <label for="config[captchas][empty]"><small><?= esc_html__('Allow as an option', '99btc-bf') ?></small></label><br>
</h4>
