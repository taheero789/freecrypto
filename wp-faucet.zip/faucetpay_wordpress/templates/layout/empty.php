<?php
/**
 * @var The99Bitcoins_BtcFaucet_Plugin $this
 * @var string $_content
 */
?>

<?php echo $_content ?>
