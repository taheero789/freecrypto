<?php

class The99Bitcoins_BtcFaucet_Claim_Payouts
{
    /** @var wpdb */
    protected $db;

    /** @var array */
    protected $config = array();

    public function __construct($config)
    {
    	$this->config = $config + $this->config;
        $this->db = $GLOBALS['wpdb'];
    }

    /**
     * Returns list of claimed payouts.
     *
     * @param string $type
     * @param string $fromDate
     * @param string $toDate
     * @param int $limit
     * @return array
     */
    public function search($type = '', $fromDate = '', $toDate = '', $limit = 1000)
    {
        $where = array();
        if ($type) {
            $where[] = "source.source = '" . esc_sql($type) . "'";
        }
        if ($fromDate && $toDate) {
            $fromDate = DateTime::createFromFormat('Y-m-d', $fromDate)
                ->setTime(0, 0, 0)->getTimestamp();
            $toDate = DateTime::createFromFormat('Y-m-d', $toDate)
                ->setTime(0, 0, 0)->getTimestamp();
            $where[] = "source.stamp >= " . $fromDate;
            $where[] = "source.stamp < " . $toDate;
        } elseif ($fromDate) {
            $fromDate = DateTime::createFromFormat('Y-m-d', $fromDate)
                ->setTime(0, 0, 0)->getTimestamp();
            $where[] = "source.stamp >= " . $fromDate;
        } elseif ($toDate) {
            $toDate = DateTime::createFromFormat('Y-m-d', $toDate)
                ->setTime(0, 0, 0)->getTimestamp();
            $where[] = "source.stamp < " . $toDate;
        }
        if ($where) {
            $where = 'WHERE ' . implode(' AND ', $where);
        } else {
            $where = '';
        }
        if ($limit) {
            $limit = ' LIMIT ' . $limit;
        } else {
            $limit = '';
        }
        return $this->db->get_results("
            SELECT
                source.*,
                address.address
            FROM
                {$this->config['db_prefix']}claim_payouts source
            LEFT JOIN
                {$this->config['db_prefix']}info_address address
            ON
                address.id = source.address_id
                {$where}
            ORDER BY
                source.stamp DESC,
                source.id DESC" . $limit, ARRAY_A);
    }

    /**
     * Returns sum of claimed payouts.
     *
     * @param string $type
     * @param string $fromDate
     * @param string $toDate
     * @param string $format
     * @param bool $resetTime
     * @return int
     */
    public function searchAmount($type = '', $fromDate = '', $toDate = '', $format = 'Y-m-d', $resetTime = true)
    {
        $where = array();
        if ($type) {
            $where[] = "source = '" . esc_sql($type) . "'";
        }
        if ($fromDate && $toDate) {
            $fromDate = DateTime::createFromFormat($format, $fromDate);
            if ($resetTime) {
                $fromDate->setTime(0, 0, 0);
            }
            $fromDate = $fromDate->getTimestamp();
            $toDate = DateTime::createFromFormat($format, $toDate);
            if ($resetTime) {
                $toDate->setTime(0, 0, 0);
            }
            $toDate = $toDate->getTimestamp();
            $where[] = "stamp >= " . $fromDate;
            $where[] = "stamp < " . $toDate;
        } elseif ($fromDate) {
            $fromDate = DateTime::createFromFormat('Y-m-d', $fromDate);
            if ($resetTime) {
                $fromDate->setTime(0, 0, 0);
            }
            $fromDate = $fromDate->getTimestamp();
            $where[] = "stamp >= " . $fromDate;
        } elseif ($toDate) {
            $toDate = DateTime::createFromFormat('Y-m-d', $toDate);
            if ($resetTime) {
                $toDate->setTime(0, 0, 0);
            }
            $toDate = $toDate->getTimestamp();
            $where[] = "stamp < " . $toDate;
        }
        if ($where) {
            $where = 'WHERE ' . implode(' AND ', $where);
        } else {
            $where = '';
        }
        return $this->db->get_var("SELECT SUM(amount) FROM {$this->config['db_prefix']}claim_payouts {$where}");
    }

    /**
     * Returns list of addresses and their claimed amount.
     *
     * @param int $threshold
     * @param string $currency
     * @param int $stamp
     * @return array
     */
    public function searchGrouped($threshold = 0, $currency = 'BTC', $stamp = 0)
    {
        $result = $this->db->get_results($this->db->prepare(
            "SELECT
                    address.address,
                    address.id address_id,
                    SUM(source.amount) as total
                FROM
                    {$this->config['db_prefix']}info_address address
                JOIN
                    {$this->config['db_prefix']}claim_payouts source
                ON
                    source.address_id = address.id 
                    AND source.paid = 'no'
                    AND source.scheduled_payouts_id = 0
                WHERE
                    address.touch > %d
                    AND address.currency = %s
                GROUP BY
                    address.id
                HAVING
                    total >= %d",
            $stamp,
            $currency,
            $threshold
        ), ARRAY_A);
        usort($result, array($this, 'searchGroupedSort'));
        return $result;
    }

    protected function searchGroupedSort($a, $b)
    {
        if ($a['total'] == $b['total']) {
            return $a['address'] > $b['address'];
        }
        return $a['total'] > $b['total'];
    }

    /**
     * Returns claimed amount for specified address.
     *
     * @param int $addressId
     * @param string $paid
     * @param string $source
     * @return int
     */
    public function getAmountByAddress($addressId, $paid = 'no', $source = '')
    {
        $where = array();
        $conditions = array();
        if ($addressId) {
            $where[] = 'address_id = %d';
            $conditions[] = $addressId;
        }
        if ($paid) {
            $where[] = 'paid = %s';
            $conditions[] = $paid;
        }
        if ($source) {
            $where[] = 'source = %s';
            $conditions[] = $source;
        }
        return $this->db->get_var($this->db->prepare("SELECT SUM(amount) FROM {$this->config['db_prefix']}claim_payouts WHERE " . implode(' AND ', $where), $conditions));
    }

    /**
     * Returns list of claimed payouts for specified address.
     *
     * @param int $addressId
     * @param int $id
     * @return array
     */
    public function searchAddress($addressId, $id = null)
    {
        if (!$id) {
            return $this->db->get_results($this->db->prepare(
                "SELECT * FROM {$this->config['db_prefix']}claim_payouts WHERE address_id = %d ORDER BY stamp DESC, id DESC LIMIT 20",
                $addressId
            ), ARRAY_A);
        } else {
            return $this->db->get_results($this->db->prepare(
                "SELECT * FROM {$this->config['db_prefix']}claim_payouts WHERE address_id = %d and id < %d ORDER BY stamp DESC, id DESC LIMIT 20",
                $addressId,
                $id
            ), ARRAY_A);
        }
    }

    /**
     * Marks related payouts of transaction as paid.
     *
     * @param $scheduledPayoutsId
     * @return bool
     */
    public function finalize($scheduledPayoutsId)
    {
        return $this->db->update("{$this->config['db_prefix']}claim_payouts", array(
            'paid' => 'yes',
        ), array(
            'scheduled_payouts_id' => $scheduledPayoutsId,
        ));
    }

    /**
     * @param int $scheduledPayoutsId
     * @return bool
     */
    public function rollback($scheduledPayoutsId)
    {
        return $this->db->update("{$this->config['db_prefix']}claim_payouts", array(
            'paid' => 'no',
            'scheduled_payouts_id' => 0,
        ), array(
            'scheduled_payouts_id' => $scheduledPayoutsId,
        ));
    }

    public function claim($addressId, $amount, $type = 'direct')
    {
        if (!$addressId) {
            return false;
        }

        $amount = ceil($amount);
        if (!$amount) {
            return false;
        }

        $this->db->insert("{$this->config['db_prefix']}claim_payouts", array(
            'stamp' => time(),
            'address_id' => $addressId,
            'amount' => $amount,
            'source' => $type,
            'paid' => 'no',
            'scheduled_payouts_id' => 0,
        ));
        return true;
    }

    /**
     * Returns sum of claimed payouts.
     *
     * @param string $type
     * @param string $fromDate
     * @param string $toDate
     * @param string $format
     * @param bool $resetTime
     * @return int
     */
    public function searchSubmits($type = '', $fromDate = '', $toDate = '', $format = 'Y-m-d', $resetTime = true)
    {
        $where = array();
        if ($type) {
            $where[] = "source = '" . esc_sql($type) . "'";
        }
        if ($fromDate && $toDate) {
            $fromDate = DateTime::createFromFormat($format, $fromDate);
            if ($resetTime) {
                $fromDate->setTime(0, 0, 0);
            }
            $fromDate = $fromDate->getTimestamp();
            $toDate = DateTime::createFromFormat($format, $toDate);
            if ($resetTime) {
                $toDate->setTime(0, 0, 0);
            }
            $toDate = $toDate->getTimestamp();
            $where[] = "stamp BETWEEN " . $fromDate . " AND " . $toDate;
        } elseif ($fromDate) {
            $fromDate = DateTime::createFromFormat('Y-m-d', $fromDate);
            if ($resetTime) {
                $fromDate->setTime(0, 0, 0);
            }
            $fromDate = $fromDate->getTimestamp();
            $where[] = "stamp >= " . $fromDate;
        } elseif ($toDate) {
            $toDate = DateTime::createFromFormat('Y-m-d', $toDate);
            if ($resetTime) {
                $toDate->setTime(0, 0, 0);
            }
            $toDate = $toDate->getTimestamp();
            $where[] = "stamp < " . $toDate;
        }
        if ($where) {
            $where = 'WHERE ' . implode(' AND ', $where);
        } else {
            $where = '';
        }
        return $this->db->get_var("SELECT count(*) total FROM {$this->config['db_prefix']}claim_payouts {$where}");
    }
}
