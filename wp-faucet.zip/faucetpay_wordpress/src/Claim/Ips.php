<?php

class The99Bitcoins_BtcFaucet_Claim_Ips
{
    /** @var wpdb */
    protected $db;

	/** @var array */
	protected $config = array();

	public function __construct($config)
	{
		$this->config = $config + $this->config;
        $this->db = $GLOBALS['wpdb'];
    }

    /**
     * @param int $addressId
     * @param int $referId
     * @param int $userId
     * @param int $ipId
     * @param bool $success
     * @return bool
     */
    public function track($addressId, $referId, $userId, $ipId, $success = false)
    {
        if (!$ipId) {
            return false;
        }

        $this->db->insert("{$this->config['db_prefix']}claim_ips", array(
            'stamp' => time(),
            'address_id' => $addressId,
            'refer_id' => $referId,
            'user_id' => $userId,
            'ip_id' => $ipId,
            'success' => $success ? 'yes' : 'no',
        ));
        return true;
    }

    /**
     * @param int $addressId
     * @param int $interval
     * @param int $stamp
     * @return int
     */
    public function countSubmitsFromDateForAddress($addressId, $interval, $stamp = 0)
    {
        if (!$addressId) {
            return 0;
        }
        if (!$stamp) {
            $stamp = time();
        }
        $interval = $stamp + $interval;

        if ($interval > $stamp) {
            $start = $stamp;
            $end = $interval;
        } else {
            $start = $interval;
            $end = $stamp;
        }

        return (int)$this->db->get_var($this->db->prepare("SELECT count(*) FROM {$this->config['db_prefix']}claim_ips WHERE address_id = %d AND stamp BETWEEN %d AND %d AND success = %s", $addressId, $start, $end, 'yes'));
    }

    /**
     * @param int $userId
     * @param int $interval
     * @param int $stamp
     * @return int
     */
    public function countSubmitsFromDateForUser($userId, $interval, $stamp = 0)
    {
        $userId = trim($userId);
        if (!$userId) {
            return 0;
        }
        if (!$stamp) {
            $stamp = time();
        }
        $interval = $stamp + $interval;

        if ($interval > $stamp) {
            $start = $stamp;
            $end = $interval;
        } else {
            $start = $interval;
            $end = $stamp;
        }

        return (int)$this->db->get_var($this->db->prepare("SELECT count(*) FROM {$this->config['db_prefix']}claim_ips WHERE user_id = %d AND stamp BETWEEN %d AND %d AND success = %s", $userId, $start, $end, 'yes'));
    }
}
