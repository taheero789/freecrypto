<?php

class The99Bitcoins_BtcFaucet_ClaimRules_ETH extends The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    const currency = 'ETH';
}
