<?php

class The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    /** @var array */
    protected $config = array();

    /** @var The99Bitcoins_BtcFaucet_Currency_Base */
    protected $currency = null;

    public function __construct($config = array(), $currency)
    {
        $this->config = $config;
        $this->currency = $currency;
    }

    public function isConfigured()
    {
        return !empty($this->config['rules']);
    }

    protected function doLottery()
    {
        $multiplier = 1;
        foreach ($this->config['rules'] as $rule) {
            $rule['probability'] *= $multiplier;
            while (round($rule['probability']) != $rule['probability']) {
                $multiplier *= 10;
                $rule['probability'] *= $multiplier;
            }
        }
        foreach ($this->config['rules'] as &$rule) {
            $rule['probability'] *= $multiplier;
        }
        unset($rule);
        $offset = 0;
        $lottery = array();
        foreach ($this->config['rules'] as $rule) {
            $offset += $rule['probability'];
            $lottery[$offset] = array($rule['amount_min'], $rule['amount_max']);
        }

        $prize = 0;
        $winner = rand(0, $offset);
        foreach ($lottery as $index => $range) {
            if ($winner <= $index) {
                if ($range[0] == $range[1]) {
                    $prize = $range[0];
                    break;
                }
                $value = $range[0];
                $multiplier = 1;
                while (round($value) != $value) {
                    $multiplier *= 10;
                    $value = $range[0] * $multiplier;
                }
                $value = $range[1] * $multiplier;
                while (round($value) != $value) {
                    $multiplier *= 10;
                    $value = $range[1] * $multiplier;
                }
                $prize = rand($range[0] * $multiplier, $range[1] * $multiplier) / $multiplier;
                break;
            }
        }
        if (!$prize && $lottery) {
            $lottery = reset($lottery);
            $prize = rand($lottery[0], $lottery[1]);
        }

        return $prize;
    }

    public function lottery()
    {
        return ceil($this->doLottery());
    }

    public function threshold()
    {
        return (int)$this->config['threshold'];
    }

    public function currency()
    {
        return $this->currency;
    }
}
