<?php

class The99Bitcoins_BtcFaucet_ClaimRules_LTC extends The99Bitcoins_BtcFaucet_ClaimRules_Base
{
    const currency = 'LTC';
}
