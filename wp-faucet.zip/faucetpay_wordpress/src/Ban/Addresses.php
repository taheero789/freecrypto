<?php

class The99Bitcoins_BtcFaucet_Ban_Addresses
{
    /** @var wpdb */
    protected $db;

    /** @var The99Bitcoins_BtcFaucet_Info_Addresses */
    protected $info;

	/** @var array */
	protected $config = array();

    public function __construct($config, The99Bitcoins_BtcFaucet_Info_Addresses $info)
    {
	    $this->config = $config + $this->config;
        $this->db = $GLOBALS['wpdb'];
        $this->info = $info;
    }

    /**
     * Returns list of banned addresses.
     *
     * @param string $address
     * @return array
     */
    public function search($address = '')
    {
        $address = trim($address);
        if ($address) {
            return $this->db->get_results($this->db->prepare(
                "SELECT * FROM {$this->config['db_prefix']}ban_address WHERE address LIKE %s ORDER BY stamp DESC LIMIT 30",
                '%' . $this->db->esc_like($address) . '%'
            ), ARRAY_A);
        } else {
            return $this->db->get_results("SELECT * FROM {$this->config['db_prefix']}ban_address ORDER BY stamp DESC LIMIT 30", ARRAY_A);
        }
    }

    /**
     * Returns list of white addresses.
     *
     * @param string $address
     * @return array
     */
    public function searchWhite($address = '')
    {
        $address = trim($address);
        if ($address) {
            return $this->db->get_results($this->db->prepare(
                "SELECT * FROM {$this->config['db_prefix']}white_address WHERE address LIKE %s ORDER BY stamp DESC LIMIT 30",
                '%' . $this->db->esc_like($address) . '%'
            ), ARRAY_A);
        } else {
            return $this->db->get_results("SELECT * FROM {$this->config['db_prefix']}white_address ORDER BY stamp DESC LIMIT 30", ARRAY_A);
        }
    }

    /**
     * Ban address and its invitees if $recursive is true.
     *
     * @param string $address
     * @param string $reason
     * @param bool $recursive
     * @return bool
     */
    public function ban($address, $reason = '', $recursive = false)
    {
        $address = trim($address);
        if (!$address) {
            return false;
        }
        if ($this->isBanned($address)) {
            return false;
        }
        $this->db->insert("{$this->config['db_prefix']}ban_address", array(
            'stamp' => time(),
            'address' => $address,
            'reason' => $reason,
        ));
        $info = $this->info->get($address);
        if ($info) {
            $ids = $this->db->get_col($this->db->prepare(
                "SELECT id FROM {$this->config['db_prefix']}scheduled_payouts WHERE address_id = %d AND stamp = 0", $info['id']
            ));
            foreach ($ids as $id) {
                $this->db->delete("{$this->config['db_prefix']}scheduled_payouts", array(
                    'id' => $id,
                ));
                $this->db->update("{$this->config['db_prefix']}claim_payouts", array(
                    'scheduled_payouts_id' => 0,
                ), array(
                    'scheduled_payouts_id' => $id
                ));
            }
            if ($recursive) {
                $addresses = $this->db->get_col($this->db->prepare(
                    "SELECT address FROM {$this->config['db_prefix']}info_address WHERE refer_id = %d GROUP BY address",
                    $info['id']
                ));
                foreach ($addresses as $record) {
                    $this->ban($record, $address, $recursive);
                }
            }
        }

        return true;
    }

    /**
     * Unban address.
     *
     * @param string $address
     * @return bool
     */
    public function unban($address)
    {
        $address = trim($address);
        if (!$address) {
            return false;
        }
        if (!$this->isBanned($address)) {
            return false;
        }
        $this->db->delete("{$this->config['db_prefix']}ban_address", array(
            'address' => $address,
        ));
        return true;
    }

    /**
     * Checks if address is banned or not.
     *
     * @param string $address
     * @return bool
     */
    public function isBanned($address)
    {
        $address = trim($address);
        if (!$address) {
            return false;
        }
        $result = $this->db->get_var($this->db->prepare(
            "SELECT 1 result FROM {$this->config['db_prefix']}ban_address WHERE address = %s",
            $address
        ));
        return $result > 0;
    }

    public function white($address, $reason = '')
    {
        $address = trim($address);
        if (!$address) {
            return false;
        }
        if ($this->isWhite($address)) {
            return false;
        }
        $this->db->insert("{$this->config['db_prefix']}white_address", array(
            'stamp' => time(),
            'address' => $address,
            'reason' => $reason,
        ));

        return true;
    }

    public function isWhite($address)
    {
        $address = trim($address);
        if (!$address) {
            return false;
        }
        $result = $this->db->get_var($this->db->prepare(
            "SELECT 1 result FROM {$this->config['db_prefix']}white_address WHERE address = %s",
            $address
        ));
        return $result > 0;
    }

    /**
     * Unwhite address.
     *
     * @param string $address
     * @return bool
     */
    public function unwhite($address)
    {
        $address = trim($address);
        if (!$address) {
            return false;
        }
        if (!$this->isWhite($address)) {
            return false;
        }
        $this->db->delete("{$this->config['db_prefix']}white_address", array(
            'address' => $address,
        ));
        return true;
    }
}
