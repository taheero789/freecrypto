<?php

class The99Bitcoins_BtcFaucet_Ban_Ips
{
    /** @var wpdb */
    protected $db;

    /** @var The99Bitcoins_BtcFaucet_Info_Ips */
    protected $info;

	/** @var array */
	protected $config = array();

    public function __construct($config, The99Bitcoins_BtcFaucet_Info_Ips $info)
    {
	    $this->config = $config + $this->config;
        $this->db = $GLOBALS['wpdb'];
        $this->info = $info;
    }

    /**
     * Returns list of banned ips.
     *
     * @param string $fromIp
     * @param string $toIp
     * @return array
     */
    public function search($fromIp = '', $toIp = '')
    {
        if (!$fromIp && $toIp) {
            $fromIp = $toIp;
            $toIp = '';
        }
        if ($fromIp && $toIp) {
            return $this->db->get_results($this->db->prepare(
                "SELECT * FROM {$this->config['db_prefix']}ban_ip WHERE ip BETWEEN %s AND %s ORDER BY stamp DESC LIMIT 30",
                inet_pton($fromIp),
                inet_pton($toIp)
            ), ARRAY_A);
        } elseif ($fromIp) {
            return $this->db->get_results($this->db->prepare(
                "SELECT * FROM {$this->config['db_prefix']}ban_ip WHERE ip <= %s AND ip_to >= %s ORDER BY stamp DESC LIMIT 30",
                inet_pton($fromIp),
                inet_pton($fromIp)
            ), ARRAY_A);
        } else {
            return $this->db->get_results("SELECT * FROM {$this->config['db_prefix']}ban_ip ORDER BY stamp DESC LIMIT 30", ARRAY_A);
        }
    }

    /**
     * Ban ip.
     *
     * @param string $ip
     * @param string $reason
     * @return bool
     */
    public function ban($ip, $reason = '')
    {
        if (!$ip) {
            return false;
        }
        list($ip, $ip_to) = $this->subnet($ip);
        if ($ip_to && $this->isBanned($ip_to) && $this->isBanned($ip)) {
            return false;
        } elseif (!$ip_to && $this->isBanned($ip)) {
            return false;
        }
        $this->db->query("
            INSERT INTO {$this->config['db_prefix']}ban_ip
            (stamp, ip, ip_to, reason) VALUES
            (" . time() . ", '" . esc_sql(inet_pton($ip)) . "', '" . esc_sql(inet_pton($ip_to)) . "', '" . esc_sql($reason) . "')
        ");
        return true;
    }

    /**
     * Ban ip range.
     *
     * @param string $ip_from
     * @param string $ip_to
     * @param string $reason
     * @return bool
     */
    public function banRange($ip_from, $ip_to, $reason = '')
    {
        if (!$ip_from) {
            return false;
        }
        if (!$ip_to) {
            return false;
        }
        if ($this->isBanned($ip_from)) {
            return false;
        }
        if ($this->isBanned($ip_to)) {
            return false;
        }
        $this->db->query("
            INSERT INTO {$this->config['db_prefix']}ban_ip
            (stamp, ip, ip_to, reason) VALUES
            (" . time() . ", '" . esc_sql(inet_pton($ip_from)) . "', '" . esc_sql(inet_pton($ip_to)) . "', '" . esc_sql($reason) . "')
        ");
        return true;
    }

    public function unbanReason($reason, $recursive = false)
    {
        $addresses = $this->db->get_col($this->db->prepare(
            "SELECT address FROM {$this->config['db_prefix']}ban_address WHERE reason = %s",
            $reason
        ));
        foreach ($addresses as $address) {
            $this->unbanAddress($address, $recursive);
        }
        $ips = $this->db->get_col($this->db->prepare("SELECT ip FROM {$this->config['db_prefix']}ban_ip WHERE reason = %s", $reason));
        foreach ($ips as $ip) {
            $this->unbanIp(inet_ntop($ip), $recursive);
        }
    }

    public function unbanIp($ip, $recursive = false) {
        $ids = $this->db->get_col($this->db->prepare("SELECT id FROM {$this->config['db_prefix']}ban_ip WHERE ip = %s", inet_pton($ip)));
        foreach ($ids as $id) {
            $this->db->delete("{$this->config['db_prefix']}ban_ip", array(
                'id' => $id,
            ));
        }
        if ($recursive) {
            $this->unbanReason('Broadcasting ban ' . $ip, $recursive);
        }
    }

    public function unbanAddress($address, $recursive = false) {
        $address = trim($address);

        $ids = $this->db->get_col($this->db->prepare("SELECT id FROM {$this->config['db_prefix']}ban_address WHERE address = %s", $address));
        foreach ($ids as $id) {
            $this->db->delete("{$this->config['db_prefix']}ban_address", array(
                'id' => $id,
            ));
        }
        if ($recursive) {
            $this->unbanReason('Child of ' . $address, $recursive);
            $this->unbanReason('Broadcasting ban ' . $address, $recursive);
        }
    }

    /**
     * Checks if ip is banned or not.
     *
     * @param string $ip
     * @return bool
     */
    public function isBanned($ip)
    {
        if (!$ip) {
            return false;
        }
        $result = $this->db->get_var($this->db->prepare(
            "SELECT 1 result FROM {$this->config['db_prefix']}ban_ip WHERE ip <= %s and ip_to >= %s",
            inet_pton($ip),
            inet_pton($ip)
        ));
        return $result > 0;
    }

    public function inSubnet($ip, $subnet)
    {
        $ip = inet_pton($ip);
        foreach ($subnet as $net) {
            list($min, $max) = $this->subnet($net);
            if (inet_pton($min) <= $ip && inet_pton($max) >= $ip) {
                return true;
            }
        }
        return false;
    }

    public function subnet($subnet)
    {
        if (preg_match('/^\d+\.\d+\.\d+\.\d+/', $subnet)) {
            return $this->subnet4($subnet);
        }
        return $this->subnet6($subnet);
    }

    protected function subnet4($subnet)
    {
        $min = 0;
        $max = 0;
        if ($subnet && strpos($subnet, '/') !== false) {
            list($min, $len) = explode('/', $subnet);
            if (($min = ip2long($min)) !== false) {
                $max = $min | (1 << (32 - $len)) - 1;
            }
        } else {
            $min = $max = ip2long($subnet);
        }

        return array(long2ip($min), long2ip($max));
    }

    protected function subnet6($subnet)
    {
        if ($subnet && strpos($subnet, '/') !== false) {
            list($firstaddrstr, $subnetlen) = explode('/', $subnet);
            $firstaddrbin = inet_pton($firstaddrstr);
            $firstaddrhex = unpack('H*', $firstaddrbin);
            $firstaddrhex = reset($firstaddrhex);
            $firstaddrstr = inet_ntop($firstaddrbin);
            $flexbits = 128 - $subnetlen;
            $lastaddrhex = $firstaddrhex;
            $pos = 31;
            while ($flexbits > 0) {
                $orig = substr($lastaddrhex, $pos, 1);
                $origval = hexdec($orig);
                $newval = $origval | (pow(2, min(4, $flexbits)) - 1);
                $new = dechex($newval);
                $lastaddrhex = substr_replace($lastaddrhex, $new, $pos, 1);
                $flexbits -= 4;
                $pos -= 1;
            }
            $lastaddrbin = pack('H*', $lastaddrhex);
            $lastaddrstr = inet_ntop($lastaddrbin);
        } else {
            $firstaddrstr = $lastaddrstr = $subnet;
        }

        return array($firstaddrstr, $lastaddrstr);
    }
}
